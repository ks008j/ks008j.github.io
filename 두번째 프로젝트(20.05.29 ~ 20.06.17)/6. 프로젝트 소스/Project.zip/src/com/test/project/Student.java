package com.test.project;

public class Student {

	public void student() {
		
		Student_Login login = new Student_Login();
		//현재쓰는 id는 hzuwo7132, 비번은 4239216
		login.Login();
		
	}//std
	
}//Student